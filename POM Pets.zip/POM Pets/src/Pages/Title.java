package Pages;

import org.openqa.selenium.WebDriver;

public class Title {
	WebDriver dr;
	public Title(WebDriver dr) {
		this.dr=dr;
	}
public String  gettitle() {
	String s= dr.getTitle();
	return s;
}
}
