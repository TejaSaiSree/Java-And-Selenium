package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utiles.ExplicitCode;

public class Signup {
WebDriver dr;
Title t= new Title(dr);
ExplicitCode e;
public Signup(WebDriver dr){
	this.dr=dr;
	e= new ExplicitCode(dr);
}
By sign=By.xpath("//a[@href='/login']");
public String  sign() {
	WebElement e_id=e.clickable(sign, 20);
	e_id.click();

	String s=dr.getTitle();
	return s;
}
}
