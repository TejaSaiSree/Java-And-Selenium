package TestNg1;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import WebBrowser.DriverE;

public class LBCMFBrowsers extends DriverE{
	DriverE l;
	String url="https://www.selenium.dev/downloads/";
	WebDriver dr;
  @Test(priority=0)
  public void f() {
	  dr=DriverE.Launch_Browser("chrome", url);
  }
  @Test(priority=1)
  public void f1() {
	  dr=DriverE.Launch_Browser("firefox", url);
  }
}
