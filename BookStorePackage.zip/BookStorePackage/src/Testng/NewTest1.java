package Testng;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import HomePage.HP2;
import HomePage.Hp1;
import HomePage.gettitle;

public class NewTest1 {
	WebDriver dr;
	gettitle g;
	Hp1 h;
	HP2  h1;
	@BeforeClass
	public void launchch() {
		System.setProperty("webdriver.gecko.driver", "geckodriver_v73.exe");
		dr= new FirefoxDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
	}
  @Test(priority=0)
  public void f() {
	  h= new Hp1(dr);
	  String s=h.searching();
	  Assert.assertTrue(s.contains("Online Bookstore"));
  }
  @Test(priority=1)
  public void f1() {
	  g= new gettitle(dr);
	  h1=new HP2(dr);
	  String s=g.gt();
	  String s1=h1.Verifyname();
	  Assert.assertTrue(s.contains("SearchResults"));
	  Assert.assertTrue(s1.contains("Perl and CGI for the World Wide Web"));
	  
  }
}
