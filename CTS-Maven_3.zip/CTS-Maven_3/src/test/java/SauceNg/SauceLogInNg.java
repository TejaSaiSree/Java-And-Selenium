package SauceNg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import Sauce.Homepage;
import Sauce.SauceLogIn;

public class SauceLogInNg {
	WebDriver dr;
    SauceLogIn p;
    Homepage h;
	@BeforeClass
	public void browser(){
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		dr=new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
	}
  @Test(priority=0)
  public void f() {
	  p= new SauceLogIn(dr);
	  h= new Homepage(dr);
	  p.login("standard_user", "secret_sauce");
	  String s=p.gettitle();
	  Assert.assertTrue(s.contains("Labs"));
  }
  @Test(priority=1)
  public void f1(){
	String q=h.getp();
	Assert.assertTrue(q.contains("Products"));
  }
  @Test(priority=2)
  public void f2(){
	String q=h.getpro();
	Assert.assertTrue(q.contains("Backpack"));
  }

}
