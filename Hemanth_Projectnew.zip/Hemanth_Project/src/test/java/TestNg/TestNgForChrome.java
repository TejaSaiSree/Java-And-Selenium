package TestNg;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Utilities.ExplicitCode;
import pomPages.LaptopVerification;
import pomPages.VerifyProducts;
import pomPages.addToCart;
import pomPages.logInPage;
import pomPages.signUpPage;


public class TestNgForChrome extends ExplicitCode{
	WebDriver dr;
	logInPage lp;
	addToCart ac;
	signUpPage sp;
	VerifyProducts vp;
	LaptopVerification lv;
	@BeforeMethod
	public void LB() {
		launchbrowser("chrome");
	}
	@BeforeClass
	public void GE() {
		getExcel("Sheet1");
	}
	@Test(priority=0,dataProvider="register")
	  public void signUp(String username,String password) {
		 sp=new signUpPage(dr);
		 sp.signUp(username,password);
		
			
	  }
	@Test(priority=1,dataProvider="register")
	  public void logIn(String username,String password) {
	
		 lp=new logInPage(dr);
			lp.LogIn(username, password);
			String r=lp.verifyLogIn();
		Assert.assertTrue(r.contains(username));
	  }
	@Test(priority=2)
	public void add(){
		ac=new addToCart(dr);
		ac.AddtoCart();
		vp=new VerifyProducts(dr);
		vp.clickcart();
		String r=vp.FP();
		String r1=vp.SP();
		Assert.assertTrue(r.contains("Samsung"));
		Assert.assertTrue(r1.contains("Nokia"));
	}
	@Test(priority=3)
	public void LaptopVerify() {
		lv=new LaptopVerification(dr);
		lv.ClickLaptop();
		String s=lv.verifylaptops();
		Assert.assertTrue(s.contains("Laptop"));
	}
	
	 @DataProvider(name="register")
	  public String[][] register(){
		   return testdata;
	  }
	 @AfterMethod
	 public void CB() {
		 dr.quit();
	 }
}
