package pkh1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class NewTest1 {
  @Test
  public void f() {
	  System.out.println("testng");
	  System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	  WebDriver r= new ChromeDriver();
	  r.get("https://www.selenium.dev/downloads/");
  }
}
