package HomePage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Hp1 {
	WebDriver dr;
	gettitle g;
public Hp1(WebDriver dr) {
	this.dr=dr;
	g=new gettitle(dr);
}
By pro=By.xpath("//select[@name='category_id']//following::option[2]");
By clc=By.xpath("//input[@name='DoSearch']");
public void programming() {
	dr.findElement(pro).click();
}
public void clicking() {
	dr.findElement(clc).click();
}
public String searching() {
	String s=g.gt();
	this.programming();
	this.clicking();
	return s;
}
}
