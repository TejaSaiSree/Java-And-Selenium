package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utiles.ExplicitCode;

public class Login {
WebDriver dr;
Title t= new Title(dr);
ExplicitCode e;
String exe="Your account has been created. Please try login !!";
public Login(WebDriver dr){
	this.dr=dr;
	e= new ExplicitCode(dr);
}
By success=By.xpath("//div[@id='Content']//li");
By username=By.xpath("//input[@name='username']");
By password=By.xpath("//input[@name='password']");
By submit=By.xpath("//input[@id='login']");
By welcome=By.xpath("//div[@id='WelcomeContent']");
public String verify() {

	String s=dr.findElement(success).getText();
	return s;
}
public String verify1() {
	String s1=dr.findElement(welcome).getText();
	return s1;
}
public void username(String s) {
	WebElement e_id=e.waitelement(username, 20);
	dr.findElement(username).sendKeys(s);
}
public void password(String s) {
	WebElement e_id=e.waitelement(password, 20);
	dr.findElement(password).sendKeys(s);
}
public void submit() {
	WebElement e_id=e.clickable(submit, 20);
	dr.findElement(submit).click();
}
public void login(String un,String pass) {
	this.username(un);
	this.password(pass);
	this.submit();
	e.Screenshot();
}
}

