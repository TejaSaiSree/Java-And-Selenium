package Storepac;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
	WebDriver dr;
	String test_re ;
	@Given("^Browser is launched and login page displayed$")
	public void browser_is_launched_and_login_page_displayed() throws Throwable {
	  System.out.println("in given");  
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	  dr= new ChromeDriver();
	  dr.get("http://examples.codecharge.com/Store/Default.php");
	  
	}
	@When("^click on programming in drop down$")
	public void click_on_programming_in_drop_down() throws Throwable {
		System.out.println("in when");
    dr.findElement(By.xpath("//select[@name='category_id']//child::option[2]")).click();
    dr.findElement(By.xpath("//input[@name='DoSearch']")).click();

	}

	@Then("^verified title and book name$")
	public void verified_title_and_book_name() throws Throwable {
		System.out.println("in then");
	  String s= dr.getTitle();
	  String p=dr.findElement(By.xpath("//table[@class='Grid']//tr[3]//td[2]//a")).getText();
	  if(s.contains("SearchResults") && p.contains("Perl")) {
		test_re = "pass";  
	  }else {
		  test_re="fail"; 
	  }
	  System.out.println(test_re);
	}
}
