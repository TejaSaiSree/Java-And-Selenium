package Sauce;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Homepage {
WebDriver dr;

@FindBy(xpath="//div[@class='product_label']")
WebElement products;

@FindBy(xpath="//a[@id='item_4_title_link']//div")
WebElement pnmae;
public Homepage(WebDriver dr){
	this.dr=dr;
	PageFactory.initElements(dr,this);
}
public String getp(){
	String s=products.getText();
	return s; 
}
public String getpro(){
	String s=pnmae.getText();
	return s;
}
}
