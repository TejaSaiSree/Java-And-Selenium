package WebBrowser;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DriverE {
 public static WebDriver Launch_Browser(String browser,String url) {
	 WebDriver dr= null;
	 switch(browser) {
	 case "chrome":
		 System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		 dr= new ChromeDriver();
		 break;
	 case "firefox":
		 System.setProperty("webdriver.gecko.driver","geckodriver_v73.exe");
		 dr= new FirefoxDriver();
		 break;		
	default:
		System.out.println("supported browser");
		break;
	 }
	 dr.get(url);
	 dr.manage().window().maximize();
	 dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	 return dr;
 }
}
