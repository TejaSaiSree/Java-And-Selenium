package testrunner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features="Feature",glue="Storepac")
public class testrunner extends AbstractTestNGCucumberTests {

}
