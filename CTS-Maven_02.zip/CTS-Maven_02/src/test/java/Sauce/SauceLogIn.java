package Sauce;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SauceLogIn {
	WebDriver dr;
@FindBy(xpath="//input[@id='user-name']")
WebElement username;

@FindBy(xpath="//input[@id='password']")
WebElement password;

@FindBy(xpath="//input[@class='btn_action']")
WebElement btn;


  
public SauceLogIn(WebDriver dr){
	this.dr=dr;
	PageFactory.initElements(dr,this);
}
public void uname(String usnmae){
	username.sendKeys(usnmae);
}
public void password(String pword){
	password.sendKeys(pword);
}
public void btn1(){
	btn.click();
}
public void login(String un,String p){
	this.uname(un);
	this.password(p);
	this.btn1();
}

public String gettitle(){
	String s=dr.getTitle();
	return s;
}
}
