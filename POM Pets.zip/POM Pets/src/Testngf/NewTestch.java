package Testngf;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pages.Login;
import Pages.RegNow;
import Pages.Register;
import Pages.Signup;
import Pages.Title;
import Utiles.ExplicitCode;

public class NewTestch {
	WebDriver dr;
	String ti="JPetStore Demo";
	String re="Your account has been created. Please try login !!";
	String lo="Welcome Tejasaisree !";
	
	
	@BeforeClass
	public void launch() {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		dr= new ChromeDriver();
		dr.get("https://jpetstore.cfapps.io/catalog");
		dr.manage().window().maximize();
	}
	@Test(priority=0)
public void f() {
		Signup s=new Signup(dr);
	s.sign();
	
  }
  @Test(priority=2)
  public void f1() {
	  Register r= new Register(dr);
	  String p=r.register();
	  Assert.assertTrue(ti.contains(p));
  }
  @Test(priority=3)
  public void f2() {
	  RegNow r1= new RegNow(dr);
	  
	String p=  r1.registration("Sree4","Tejaswarup", "Tejaswarup", "Tejasaisree", "velpucherla","tejasaisree98abcd@gmail.com", "9856321477", "1/2270", "1/2270","Kadapa", "Ap", "510446", "India");
	 Assert.assertTrue(ti.contains(p));
	
  }
  @Test(priority=4)
  public void f3() { 
	  Login l=new Login(dr);
	  String s=l.verify();
		Assert.assertEquals(re,s);
  l.login("Sree4", "Tejaswarup");
  String s1=l.verify1();
  Assert.assertTrue(lo.contains(s1));
  dr.close();
  }
}
