package Testngf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pages.Login;
import Utiles.ExplicitCode;
import getExcel.getnumpass;

public class NewTest1 extends getnumpass {
	static WebDriver dr;
	getnumpass e;
	String re="Your account has been created. Please try login !!";
	String lo="Welcome Tejasaisree !";
	ExplicitCode e1;
	@BeforeClass
	public void launch() {
		
		  getExcel("Sheet1");
		  e1= new ExplicitCode (dr);
		e1.logger1("completed getexcel");
	}@BeforeMethod
	public void test() {
		dr=ExplicitCode.launchbrowser("firefox");
		e1.logger1("firefox browser launched");
	}
  @Test(dataProvider="register")
  public void f(String s,String b,String s2) {
	  
	  Login l=new Login(dr);
	
	  l.login(s,b);
	  e1.logger1("login successful"+s+" "+b);
  String s1=l.verify1();
  Assert.assertTrue(s2.contains(s1));
  dr.close();
  }
  @DataProvider(name="register")
  public String[][] register(){
	  return testdata;
			 
	   }
}
