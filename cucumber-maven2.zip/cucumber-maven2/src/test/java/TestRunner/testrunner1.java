package TestRunner;

import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features="src\\main\\resources\\Feature",glue="SauceNg")
public class testrunner1 extends AbstractTestNGCucumberTests{

}
